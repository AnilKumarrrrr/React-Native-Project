import React, { useRef, useState, useEffect } from "react";
import {
  View,
  Image,
  StyleSheet,
  Dimensions,
  Text,
  Pressable,
  Animated
} from "react-native";

const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
const winnerPlatformHeight = 100; // Adjust this height according to your image

const App = () => {
  const [currentScreen, setCurrentScreen] = useState(1);
  const [countdown, setCountdown] = useState("04:52:60");
  const [animatedValue] = useState(new Animated.Value(0));

  useEffect(() => {
    let interval;
    let timeout;

    const startCountdown = () => {
      let secondsLeft = 3;
      setCountdown("04:52:60");

      interval = setInterval(() => {
        setCountdown((prevCountdown) => {
          const [hours, minutes, seconds] = prevCountdown.split(":");
          let newSeconds = parseInt(seconds, 10) - 1;
          let newMinutes = parseInt(minutes, 10);
          let newHours = parseInt(hours, 10);

          if (newSeconds < 0) {
            newSeconds = 59;
            newMinutes -= 1;
          }
          if (newMinutes < 0) {
            newMinutes = 59;
            newHours -= 1;
          }
          return `${newHours
            .toString()
            .padStart(2, "0")}:${newMinutes
            .toString()
            .padStart(2, "0")}:${newSeconds.toString().padStart(2, "0")}`;
        });
      }, 1000);

      timeout = setTimeout(() => {
        clearInterval(interval);
        setCurrentScreen((prevScreen) => (prevScreen < 3 ? prevScreen + 1 : 1));
      }, secondsLeft * 1000);
    };

    startCountdown();

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  useEffect(() => {
    if (currentScreen === 2) {
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true
      }).start();
    } else {
      animatedValue.setValue(0);
    }
  }, [currentScreen]);

  const handleNextScreen = () => {
    Animated.timing(animatedValue, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true
    }).start(() => {
      setCurrentScreen((prevScreen) => (prevScreen < 3 ? prevScreen + 1 : 1));
      animatedValue.setValue(0);

      // Restart countdown on screen 1
      if (currentScreen === 3) {
        setCountdown("04:52:60");
        setTimeout(() => {
          setCurrentScreen(2);
        }, 3000);
      }
    });
  };

  const renderScreen1 = () => (
    <View style={styles.screenContainer}>
      <Image
        source={require("./assets/background_image.png")}
        style={styles.backgroundImage}
      />
      <Text style={styles.resultText}>The Result R In</Text>
      <Text style={styles.castText}>CASTING CALL</Text>
      <Image
        source={require("./assets/cut_symbol.png")}
        style={styles.cutSymbol}
      />
      <View style={styles.userInfo}>
        <Text style={styles.countdownText}>{countdown}</Text>
      </View>
      <View style={styles.winnerPlatformContainer}>
        <Image
          source={require("./assets/winner_platform.png")}
          style={styles.winnerPlatform}
        />
      </View>
      <Image
        source={require("./assets/girl_image.png")}
        style={styles.girlImage}
      />
    </View>
  );

  const renderScreen2 = () => {
    const initialTranslateX = animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [windowWidth, 0]
    });

    const finalTranslateX = animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [0, -windowWidth]
    });

    const listerTextStyles = [
      styles.listerText,
      {
        opacity: animatedValue,
        transform: [{ translateX: initialTranslateX }]
      }
    ];

    const sallyTextStyles = [
      styles.sallyText,
      {
        opacity: animatedValue,
        transform: [{ translateX: initialTranslateX }]
      }
    ];

    const profileSymbolStyles = [
      styles.profileSymbol,
      {
        opacity: animatedValue,
        transform: [{ translateX: initialTranslateX }]
      }
    ];

    return (
      <View style={styles.screenContainer}>
        <Image
          source={require("./assets/background_image.png")}
          style={styles.backgroundImage}
        />
        <Animated.Text style={listerTextStyles}>D-Lister</Animated.Text>
        <Animated.Text style={sallyTextStyles}>Sally</Animated.Text>
        <Text style={styles.loveText}>Gave U Some Love</Text>
        <Image
          source={require("./assets/heart_image.png")}
          style={styles.heartSymbol}
        />
        <Text style={styles.numberText}>15000</Text>
        <Animated.Image
          source={require("./assets/user_profile_picture.png")}
          style={profileSymbolStyles}
        />
        <View style={styles.winnerPlatformContainer}>
          <Image
            source={require("./assets/winner_platform.png")}
            style={styles.winnerPlatform}
          />
        </View>
        <Image
          source={require("./assets/girl_image.png")}
          style={styles.girlImage}
        />
        {currentScreen === 2 && (
          <Pressable style={styles.nextButton} onPress={handleNextScreen}>
            <Image
              source={require("./assets/next_button.png")}
              style={styles.nextButtonImage}
            />
          </Pressable>
        )}
      </View>
    );
  };

  const renderScreen3 = () => (
    <View style={styles.screenContainer}>
      <Image
        source={require("./assets/background_image.png")}
        style={styles.backgroundImage}
      />
      <Text style={styles.friend1Text}>4 Friends Gave U</Text>
      <Text style={styles.friend2Text}>Some Love</Text>
      <View style={styles.winnerPlatformContainer}>
        <Image
          source={require("./assets/heart_image.png")}
          style={styles.heartSymbol}
        />
        <Text style={styles.numbercountdownText}>15000</Text>
        <Image
          source={require("./assets/winner_platform.png")}
          style={styles.winnerPlatform}
        />
      </View>
      <Image
        source={require("./assets/girl_image.png")}
        style={styles.girlImage}
      />
      {currentScreen === 3 && (
        <Pressable style={styles.nextButton} onPress={handleNextScreen}>
          <Image
            source={require("./assets/next_button.png")}
            style={styles.nextButtonImage}
          />
        </Pressable>
      )}
    </View>
  );

  // Render the appropriate screen based on the current screen state
  let currentScreenComponent;
  if (currentScreen === 1) {
    currentScreenComponent = renderScreen1();
  } else if (currentScreen === 2) {
    currentScreenComponent = renderScreen2();
  } else {
    currentScreenComponent = renderScreen3();
  }

  return currentScreenComponent;
};

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    position: "relative",
    justifyContent: "flex-end",
    alignItems: "center" // Center align content horizontally
  },
  backgroundImage: {
    ...StyleSheet.absoluteFillObject,
    zIndex: -1
  },
  winnerPlatformContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: winnerPlatformHeight
  },
  winnerPlatform: {
    width: windowWidth,
    height: winnerPlatformHeight,
    resizeMode: "cover"
  },
  girlImage: {
    position: "absolute",
    top: windowHeight - 350,
    width: windowWidth,
    height: windowHeight - winnerPlatformHeight - 290,
    resizeMode: "contain"
  },
  resultText: {
    position: "absolute",
    bottom: 380,
    color: "#FFFFCC", // Light yellow color
    fontSize: 25, // Increased font size
    textAlign: "center"
  },
  castText: {
    position: "absolute",
    bottom: 450,
    color: "purple",
    fontSize: 25,
    textAlign: "center",
    fontFamily: "YourCurlyFont", // Replace "YourCurlyFont" with the actual font family name
    transform: [{ rotate: "-5deg" }]
  },
  cutSymbol: {
    position: "absolute",
    bottom: 480,
    width: 120,
    height: 120,
    resizeMode: "contain",
    alignSelf: "center"
  },
  countdownText: {
    position: "absolute",
    bottom: 505,
    color: "#D0D0D0",
    left: -33,
    fontSize: 17,
    textAlign: "center",
    transform: [{ rotate: "-15deg" }]
  },
  profileSymbol: {
    position: "absolute",
    bottom: 530,
    width: 90,
    height: 90,
    left: 80,
    borderRadius: 50,
    resizeMode: "contain",
    alignSelf: "center"
  },
  heartSymbol: {
    position: "absolute",
    bottom: 340,
    width: 130,
    height: 130,
    resizeMode: "contain",
    alignSelf: "center"
  },
  loveText: {
    position: "absolute",
    bottom: 480,
    color: "yellow",
    fontSize: 30,
    textAlign: "center"
  },
  listerText: {
    position: "absolute",
    bottom: 580,
    right: 90,
    color: "yellow", // Light yellow color
    fontSize: 25, // Increased font size
    textAlign: "center"
  },
  numberText: {
    position: "absolute",
    bottom: 390,
    color: "yellow", // Light yellow color
    fontSize: 25, // Increased font size
    textAlign: "center"
  },
  sallyText: {
    position: "absolute",
    bottom: 550,
    right: 120,
    color: "purple",
    fontSize: 20,
    textAlign: "center"
  },
  friend1Text: {
    position: "absolute",
    bottom: 530,
    color: "yellow",
    fontSize: 30,
    textAlign: "center"
  },
  friend2Text: {
    position: "absolute",
    bottom: 500,
    color: "yellow",
    fontSize: 30,
    textAlign: "center"
  },
  numbercountdownText: {
    position: "absolute",
    bottom: 390,
    left: 155,
    color: "yellow", // Light yellow color
    fontSize: 25, // Increased font size
    textAlign: "center"
  },
  nextButton: {
    position: "absolute",
    bottom: 108,
    right: 10,
    borderRadius: 5
  },
  nextButtonImage: {
    width: 40,
    height: 40,
    resizeMode: "contain"
  },
  screen2Text: {
    fontSize: 24,
    fontWeight: "bold"
  }
});

export default App;
